# Pocket AI — 0.3 native source

Joe's personal AI project: local chat and memory, local image generation, and optional cloud power. The final product is intended to combine a familiar conversational interface with selectable local models and Draw Things-based image tools.

Checkpoint includes an unfinished `ImageRepository.swift` for the next image section. It is not wired into the project or validated. Read `RESUME-HERE.md` before continuing.

## This version
- A native SwiftUI iPhone project: open `PocketAI.xcodeproj` in Xcode.
- Conversations and editable memory, stored on the device.
- First real chat adapter: Apple's **on-device** Foundation Models API, with availability status, streaming, cancellation, short recent context, and retry.
- Failed disk writes preserve displayed state; a generated reply that cannot be saved stays visible for retry while the app remains alive.
- Image ideas can be saved and reopened. Image generation is not connected yet.
- Downloadable Qwen models with progress, cancellation, SHA verification, local loading through MLX, and deletion. No model weights are bundled in this source archive.
- No cloud providers, API keys, billing, or remote app control.

Apple and downloaded Qwen models can now be selected in Settings > Chat model. All engine integrations remain uncompiled and untested on Joe's phone. MediaGenerationKit image generation is the next section.

## Validation status
Before the unfinished image repository was added, Swift syntax parsed successfully for all ten Swift files. The Xcode project was parsed and its graph references validated. The shared scheme is valid XML and the build script passed shell syntax validation. **No Swift compilation, XCTest execution, simulator rendering, or iPhone run has occurred:** this workspace has neither Xcode nor the Apple SDKs.

See [build instructions](docs/BUILD-AND-TEST.md), [execution sections](docs/ROADMAP.md), and [resume checkpoint](RESUME-HERE.md).
