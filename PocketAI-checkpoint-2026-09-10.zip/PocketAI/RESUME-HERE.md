# Pocket AI — latest checkpoint

Paused September 10, 2026 at Joe’s explicit request to save this exact stopping point. Working name: Pocket AI. User has not chosen a final name.

## Goal and device
A personal native app combining a ChatGPT-style experience, Locally AI-style local model selection, and Draw Things-style local images. Local first; optional cloud for tasks beyond the phone. Target: Joe's iPhone 17e on iOS 27. Actual model performance must be measured.

## Exact stopping point
The last complete source section is 0.3 (downloadable chat models). Image integration has just begun: `PocketAI/ImageRepository.swift` exists as unfinished source, but is NOT in the Xcode project, wired to the UI, syntax validated, or tested. No image engine or gallery integration has been completed. Resume by reading `docs/IMAGE-INTEGRATION-NOTES.md` and inspecting this file; continue from it without recreating completed chat/model work.

## Last complete section: 0.3 source
- Complete Xcode app and test project plus shared scheme now exist.
- Eight application Swift files now include MLXChatEngine, ModelCatalog, ModelLibrary, and ModelManagerView alongside the original foundation.
- Chat, history, editable memory, image idea storage, engine status, and settings implemented in source.
- Initial real chat adapter uses Apple's on-device Foundation Models API, with availability handling, streaming, stop/retry, limited recent context/memory, and persisted assistant replies. No fake reply generator is used by the app. The test-only fake engine is confined to the test target.
- Failed saves do not change persisted/visible state; generated responses that fail to save remain in memory for retry.
- Seventeen XCTest cases in two test files. No tests have been executed.
- Qwen3 0.6B and 1.7B 4-bit catalog entries use verified Hugging Face revision IDs, exact file sizes, SHA-256/LFS and Git blob hashes. Download controls, atomic staging, cancellation, removal, and offline-directory MLX loading are written. No weights were downloaded here.
- MLX Swift LM 3.31.3 and Swift Transformers 1.3.0 are pinned in the Xcode generator/project. Resolve their transitive packages in Xcode; they have not been compiled here.
- Native project generation and a macOS build/test helper are included.

## Validation and outstanding gate
Before the unfinished ImageRepository.swift was added, all ten Swift files passed tree-sitter syntax parsing. An alert-closure syntax issue was found and corrected. The PBX project passed OpenStep parsing; all generated graph references were validated, including app/test targets. Scheme XML and build-script shell syntax passed.

This workspace is Linux and has no Swift compiler, Xcode, or Apple SDK. NO type compilation, XCTest execution, simulator rendering, phone installation, or model generation has happened. Do not describe this as a functioning installed app or a completed device test. The next gate is a compatible Mac/Xcode build and actual iPhone validation.

## Resume actions
1. Joe will provide the MacBook Air screenshot tonight. Do not ask again during source work. Its model/year and macOS are still unknown; no assumption of modern Xcode support is justified.
2. Use docs/BUILD-AND-TEST.md to build and run XCTest in a compatible Apple environment. Fix any compiler/API/actor issues that appear; static syntax parsing is not enough.
3. Validate the initial Apple on-device adapter, UI, relaunch persistence, and offline generation on Joe's iPhone. The system model's limits still apply.
4. Current source work: resume the unfinished MediaGenerationKit local-image section from docs/IMAGE-INTEGRATION-NOTES.md and the existing ImageRepository.swift. Do not recreate the completed downloadable-model section. Its device tests remain pending. Use docs/ROADMAP.md.
5. Optional cloud, voice, attachments, and ChatGPT connectivity follow as separately verified sections.

## Still not implemented
Image generation, cloud providers/billing, voice, attachments, rich memory retrieval/export, or direct control from ChatGPT. No GitHub repo, paid service, or deployment has been created.

## Storage continuity
Update the existing project checkpoint archive as a new version, preserving its identity. Read the latest archive when resuming from another workspace. The earlier 0.1 source is retained through version history.

## Communication
Joe wants concise, verified answers, action in sections, and one practical question at a time when needed. Avoid the phrase 'checking'. He has said he will keep ChatGPT open; do not claim this grants remote access to his phone or solves native signing/build requirements.
